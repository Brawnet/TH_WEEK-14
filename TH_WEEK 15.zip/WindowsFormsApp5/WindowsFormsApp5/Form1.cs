﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection connect;
        MySqlCommand command;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();
        DataTable dt2 = new DataTable();
        DataTable isi = new DataTable();
        DataTable ID = new DataTable();
        string query;
        string query2;
        int Counter;
        

        private void Form1_Load(object sender, EventArgs e)
        {
            connect = new MySqlConnection("server = localhost; uid = root; pwd = YehezkielBrawnet250105; database = premier_league");
            connect.Open();
            connect.Close();
            query = "select team_name,team_id from team";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dt);
            CB_TeamHome.DataSource = dt;
            CB_TeamHome.ValueMember = "team_id";
            CB_TeamHome.DisplayMember = "team_name";

            query2 = "select team_name,team_id from team";
            command = new MySqlCommand(query2, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dt2);
            CB_TeamAway.DataSource = dt2;
            CB_TeamAway.ValueMember = "team_id";
            CB_TeamAway.DisplayMember = "team_name";

            CB_TeamHome.Text = " ";
            CB_TeamAway.Text = " ";

            isi.Columns.Add("minute");
            isi.Columns.Add("team");
            isi.Columns.Add("player");
            isi.Columns.Add("type");

            DGV.DataSource = isi;

        }

        private void cb_home_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Counter > 6)
            {
                if (CB_TeamHome.Text == CB_TeamAway.Text)
                {
                    ID = new DataTable();
                    MessageBox.Show("Tidak bole sama");
                    CB_TeamHome.Text = " ";

                }
                if (CB_TeamHome != null & CB_TeamAway != null)
                {
                    CB_Team.Items.Clear();
                    CB_Team.Items.Add(CB_TeamHome.Text);
                    CB_Team.Items.Add(CB_TeamAway.Text);
                }
            }
            else
            {
                Counter++;
            }
        }

        private void cb_away_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Counter > 6)
            {
                if (CB_TeamHome.Text == CB_TeamAway.Text)
                {
                    MessageBox.Show("Tidak bole sama");
                    CB_TeamAway.Text = " ";
                }
                if (CB_TeamHome.Text != " " & CB_TeamAway.Text != " ")
                {
                    ID = new DataTable();
                    string Query = "SELECT * FROM `Match` ORDER BY match_id DESC LIMIT 1;";
                    command = new MySqlCommand(Query, connect);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(ID);

                    TXT_MatchID.Text = ID.Rows[0][0].ToString();
                    CB_Team.Items.Clear();
                    CB_Team.Items.Add(CB_TeamHome.Text);
                    CB_Team.Items.Add(CB_TeamAway.Text);
                }
            }
            else
            {
                Counter++;
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable player = new DataTable();
            string query = "select player_name from player left join team on team.team_name = '" + CB_Team.Text + "' where player.team_id = team.team_id AND status = 1 group by player_name";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(player);
            CB_Player.DataSource = player;
            CB_Player.DisplayMember = "player";
            CB_Player.ValueMember = "player_name";
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (TXT_Minute.Text == "" || CB_Team.Text == "" || CB_Player.Text == "" || CB_Type.Text == "")
            {
                MessageBox.Show("ada yang kosong");
            }
            else
            {
                isi.Rows.Add(TXT_Minute.Text, CB_Team.Text, CB_Player.Text, CB_Type.Text);
                TXT_Minute.Text = null;
                CB_Team.SelectedItem = null;
                CB_Player.SelectedItem = null;
                CB_Type.SelectedItem = null;
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            foreach(DataGridViewRow dr in DGV.SelectedRows)
            {
                DGV.Rows.RemoveAt(dr.Index);
            }
        }

        private void TXT_MatchID_TextChanged(object sender, EventArgs e)
        {

        }

        private void BT_Insert_Click(object sender, EventArgs e)
        {

        }
    }
}
